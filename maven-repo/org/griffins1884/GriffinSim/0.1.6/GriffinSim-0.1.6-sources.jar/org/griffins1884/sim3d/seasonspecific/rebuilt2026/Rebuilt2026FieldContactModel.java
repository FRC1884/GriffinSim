package org.griffins1884.sim3d.seasonspecific.rebuilt2026;

import edu.wpi.first.math.geometry.Pose2d;
import edu.wpi.first.math.geometry.Pose3d;
import edu.wpi.first.math.geometry.Rotation3d;
import edu.wpi.first.math.geometry.Translation2d;
import edu.wpi.first.math.geometry.Translation3d;
import edu.wpi.first.math.util.Units;
import java.util.ArrayList;
import java.util.List;
import org.griffins1884.sim3d.ChassisFootprint;
import org.griffins1884.sim3d.TerrainContactModel;
import org.griffins1884.sim3d.TerrainContactSample;
import org.griffins1884.sim3d.TerrainFeature;
import org.griffins1884.sim3d.TerrainSample;
import org.griffins1884.sim3d.integration.FieldMarkerProvider;
import org.griffins1884.sim3d.integration.FieldMarkerSample;

/**
 * Standalone 2026 rebuilt field terrain/contact model.
 *
 * <p>This encodes the traversable bump surfaces and trench underpass clearance windows as explicit field
 * geometry, without depending on any robot-season repository or deploy assets.
 */
public final class Rebuilt2026FieldContactModel implements TerrainContactModel, FieldMarkerProvider {
  private static final double GRADIENT_SAMPLE_METERS = 0.02;

  private static final double FIELD_LENGTH_METERS = Units.inchesToMeters(650.12);
  private static final double FIELD_WIDTH_METERS = Units.inchesToMeters(316.64);
  private static final double CAD_FIELD_ORIGIN_X_METERS = 8.2497799;
  private static final double CAD_FIELD_ORIGIN_Y_METERS = 4.0213534;

  private static final double HUB_CENTER_X_BLUE_METERS = Units.inchesToMeters(178.0575);
  private static final double HUB_CENTER_X_RED_METERS = Units.inchesToMeters(472.0625);
  private static final double HUB_CENTER_Y_METERS = Units.inchesToMeters(158.32);
  private static final double HUB_COLLISION_WIDTH_METERS = Units.inchesToMeters(58.41);
  private static final double HUB_COLLISION_HEIGHT_METERS = Units.inchesToMeters(47.00);
  private static final RectRegion BLUE_HUB_BOUNDS =
      centeredRect(
          HUB_CENTER_X_BLUE_METERS,
          HUB_CENTER_Y_METERS,
          HUB_COLLISION_WIDTH_METERS,
          HUB_COLLISION_HEIGHT_METERS);
  private static final RectRegion RED_HUB_BOUNDS =
      centeredRect(
          HUB_CENTER_X_RED_METERS,
          HUB_CENTER_Y_METERS,
          HUB_COLLISION_WIDTH_METERS,
          HUB_COLLISION_HEIGHT_METERS);

  private static final RectRegion BLUE_LEFT_BUMP_BOUNDS = cadRect(-4208.7, -3081.1, 517.9, 2751.1);
  private static final RectRegion BLUE_RIGHT_BUMP_BOUNDS =
      cadRect(-4208.7, -3081.1, -2751.1, -517.9);
  private static final RectRegion RED_LEFT_BUMP_BOUNDS = cadRect(3081.1, 4208.7, 517.9, 2751.1);
  private static final RectRegion RED_RIGHT_BUMP_BOUNDS = cadRect(3081.1, 4208.7, -2751.1, -517.9);

  private static final double TRENCH_CENTER_X_BLUE_METERS = Units.inchesToMeters(181.555);
  private static final double TRENCH_CENTER_X_RED_METERS = Units.inchesToMeters(468.555);
  private static final double TRENCH_UPPER_CENTER_Y_METERS = Units.inchesToMeters(291.79);
  private static final double TRENCH_LOWER_CENTER_Y_METERS = Units.inchesToMeters(24.85);
  private static final double TRENCH_FOOTPRINT_DEPTH_METERS = Units.inchesToMeters(24.97);
  private static final double TRENCH_FOOTPRINT_WIDTH_METERS = Units.inchesToMeters(47.00);
  private static final double TRENCH_SUPPORT_DEPTH_METERS = Units.inchesToMeters(12.00);
  private static final double TRENCH_SIDE_WALL_SPAN_METERS =
      TRENCH_FOOTPRINT_DEPTH_METERS - TRENCH_SUPPORT_DEPTH_METERS;

  private static final RectRegion BLUE_LEFT_TRENCH_OPEN_BOUNDS =
      centeredRect(
          TRENCH_CENTER_X_BLUE_METERS,
          TRENCH_UPPER_CENTER_Y_METERS,
          TRENCH_FOOTPRINT_DEPTH_METERS,
          TRENCH_FOOTPRINT_WIDTH_METERS);
  private static final RectRegion BLUE_RIGHT_TRENCH_OPEN_BOUNDS =
      centeredRect(
          TRENCH_CENTER_X_BLUE_METERS,
          TRENCH_LOWER_CENTER_Y_METERS,
          TRENCH_FOOTPRINT_DEPTH_METERS,
          TRENCH_FOOTPRINT_WIDTH_METERS);
  private static final RectRegion RED_LEFT_TRENCH_OPEN_BOUNDS =
      centeredRect(
          TRENCH_CENTER_X_RED_METERS,
          TRENCH_UPPER_CENTER_Y_METERS,
          TRENCH_FOOTPRINT_DEPTH_METERS,
          TRENCH_FOOTPRINT_WIDTH_METERS);
  private static final RectRegion RED_RIGHT_TRENCH_OPEN_BOUNDS =
      centeredRect(
          TRENCH_CENTER_X_RED_METERS,
          TRENCH_LOWER_CENTER_Y_METERS,
          TRENCH_FOOTPRINT_DEPTH_METERS,
          TRENCH_FOOTPRINT_WIDTH_METERS);

  private static final RectRegion BLUE_LEFT_TRENCH_BLOCK_BOUNDS =
      trenchSupportBox(TRENCH_CENTER_X_BLUE_METERS, TRENCH_UPPER_CENTER_Y_METERS, true);
  private static final RectRegion BLUE_RIGHT_TRENCH_BLOCK_BOUNDS =
      trenchSupportBox(TRENCH_CENTER_X_BLUE_METERS, TRENCH_LOWER_CENTER_Y_METERS, true);
  private static final RectRegion RED_LEFT_TRENCH_BLOCK_BOUNDS =
      trenchSupportBox(TRENCH_CENTER_X_RED_METERS, TRENCH_UPPER_CENTER_Y_METERS, false);
  private static final RectRegion RED_RIGHT_TRENCH_BLOCK_BOUNDS =
      trenchSupportBox(TRENCH_CENTER_X_RED_METERS, TRENCH_LOWER_CENTER_Y_METERS, false);

  private static final double BUMP_HEIGHT_METERS = Units.inchesToMeters(6.513);
  private static final double BUMP_RAMP_FRACTION = 0.34;
  private static final double TRENCH_OPENING_HEIGHT_METERS = Units.inchesToMeters(22.25);

  private static final double TRENCH_EDGE_WALL_WIDTH_METERS = Units.inchesToMeters(7.655);
  private static final double TOWER_INNER_OPENING_WIDTH_METERS = Units.inchesToMeters(32.250);
  private static final double TOWER_UPRIGHT_OFFSET_METERS = Units.inchesToMeters(0.75);
  private static final double TOWER_UPRIGHT_HEIGHT_METERS = Units.inchesToMeters(72.1);

  private static final double TOWER_FRONT_FACE_X_METERS = Units.inchesToMeters(0.55);
  private static final double RED_TOWER_FRONT_FACE_X_METERS = Units.inchesToMeters(649.57);
  private static final double TOWER_WIDTH_METERS = Units.inchesToMeters(47.00);
  private static final double TOWER_DEPTH_METERS = Units.inchesToMeters(40.00);
  private static final double TOWER_SIDE_WIDTH_METERS =
      (TOWER_WIDTH_METERS - TOWER_INNER_OPENING_WIDTH_METERS) * 0.5;
  private static final double BLUE_TOWER_CENTER_Y_METERS =
      Units.inchesToMeters((146.86 + 163.86) * 0.5);
  private static final double RED_TOWER_CENTER_Y_METERS =
      Units.inchesToMeters((152.78 + 169.78) * 0.5);

  public static final Rebuilt2026FieldContactModel INSTANCE = new Rebuilt2026FieldContactModel();

  private Rebuilt2026FieldContactModel() {}

  @Override
  public TerrainSample sample(Pose2d robotPose) {
    Translation2d translation = robotPose.getTranslation();
    double z = bumpHeightMeters(translation);
    double[] gradient = terrainGradient(translation);

    double yaw = robotPose.getRotation().getRadians();
    double forwardSlope = (gradient[0] * Math.cos(yaw)) + (gradient[1] * Math.sin(yaw));
    double rightSlope = (-gradient[0] * Math.sin(yaw)) + (gradient[1] * Math.cos(yaw));

    double pitch = -Math.atan(forwardSlope);
    double roll = -Math.atan(rightSlope);
    Pose3d pose3d =
        new Pose3d(robotPose.getX(), robotPose.getY(), z, new Rotation3d(roll, pitch, yaw));
    return new TerrainSample(pose3d, roll, pitch, z);
  }

  @Override
  public TerrainContactSample sampleContact(Pose2d robotPose, ChassisFootprint chassisFootprint) {
    TerrainSample terrainSample = sample(robotPose);
    TerrainFeature feature = featureAt(robotPose.getTranslation());
    double overheadClearanceMeters = overheadClearanceMeters(feature);
    double underbodyClearanceMarginMeters =
        chassisFootprint.groundClearanceMeters() - terrainSample.heightMeters();
    double overheadClearanceMarginMeters =
        Double.isFinite(overheadClearanceMeters)
            ? overheadClearanceMeters - chassisFootprint.heightMeters()
            : Double.POSITIVE_INFINITY;
    boolean traversableSurface = traversableSurface(feature);
    boolean clearanceSatisfied = traversableSurface && overheadClearanceMarginMeters >= 0.0;
    return new TerrainContactSample(
        terrainSample,
        feature,
        overheadClearanceMeters,
        underbodyClearanceMarginMeters,
        overheadClearanceMarginMeters,
        traversableSurface,
        clearanceSatisfied);
  }

  @Override
  public FieldMarkerSample[] getFieldMarkers() {
    List<FieldMarkerSample> markers = new ArrayList<>();
    addHubMarkers(markers);
    addBumpMarkers(markers);
    addTrenchMarkers(markers);
    addTrenchEdgeMarkers(markers);
    addTowerMarkers(markers);
    return markers.toArray(FieldMarkerSample[]::new);
  }

  public TerrainFeature featureAt(Translation2d position) {
    if (contains(BLUE_HUB_BOUNDS, position)) {
      return TerrainFeature.BLUE_HUB;
    }
    if (contains(RED_HUB_BOUNDS, position)) {
      return TerrainFeature.RED_HUB;
    }
    if (inBlueTower(position)) {
      return TerrainFeature.BLUE_TOWER;
    }
    if (inRedTower(position)) {
      return TerrainFeature.RED_TOWER;
    }
    if (contains(BLUE_LEFT_TRENCH_BLOCK_BOUNDS, position)) {
      return TerrainFeature.BLUE_LEFT_TRENCH_EDGE;
    }
    if (contains(BLUE_RIGHT_TRENCH_BLOCK_BOUNDS, position)) {
      return TerrainFeature.BLUE_RIGHT_TRENCH_EDGE;
    }
    if (contains(RED_LEFT_TRENCH_BLOCK_BOUNDS, position)) {
      return TerrainFeature.RED_LEFT_TRENCH_EDGE;
    }
    if (contains(RED_RIGHT_TRENCH_BLOCK_BOUNDS, position)) {
      return TerrainFeature.RED_RIGHT_TRENCH_EDGE;
    }
    if (contains(BLUE_LEFT_BUMP_BOUNDS, position)) {
      return TerrainFeature.BLUE_LEFT_BUMP;
    }
    if (contains(BLUE_RIGHT_BUMP_BOUNDS, position)) {
      return TerrainFeature.BLUE_RIGHT_BUMP;
    }
    if (contains(RED_LEFT_BUMP_BOUNDS, position)) {
      return TerrainFeature.RED_LEFT_BUMP;
    }
    if (contains(RED_RIGHT_BUMP_BOUNDS, position)) {
      return TerrainFeature.RED_RIGHT_BUMP;
    }
    if (contains(BLUE_LEFT_TRENCH_OPEN_BOUNDS, position)) {
      return TerrainFeature.BLUE_LEFT_TRENCH;
    }
    if (contains(BLUE_RIGHT_TRENCH_OPEN_BOUNDS, position)) {
      return TerrainFeature.BLUE_RIGHT_TRENCH;
    }
    if (contains(RED_LEFT_TRENCH_OPEN_BOUNDS, position)) {
      return TerrainFeature.RED_LEFT_TRENCH;
    }
    if (contains(RED_RIGHT_TRENCH_OPEN_BOUNDS, position)) {
      return TerrainFeature.RED_RIGHT_TRENCH;
    }
    return TerrainFeature.FLAT;
  }

  public double bumpHeightMeters(Translation2d fieldTranslation) {
    return Math.max(
        Math.max(
            profileHeight(fieldTranslation, BLUE_LEFT_BUMP_BOUNDS),
            profileHeight(fieldTranslation, BLUE_RIGHT_BUMP_BOUNDS)),
        Math.max(
            profileHeight(fieldTranslation, RED_LEFT_BUMP_BOUNDS),
            profileHeight(fieldTranslation, RED_RIGHT_BUMP_BOUNDS)));
  }

  private double[] terrainGradient(Translation2d point) {
    double dzdx =
        (bumpHeightMeters(point.plus(new Translation2d(GRADIENT_SAMPLE_METERS, 0.0)))
                - bumpHeightMeters(point.minus(new Translation2d(GRADIENT_SAMPLE_METERS, 0.0))))
            / (2.0 * GRADIENT_SAMPLE_METERS);
    double dzdy =
        (bumpHeightMeters(point.plus(new Translation2d(0.0, GRADIENT_SAMPLE_METERS)))
                - bumpHeightMeters(point.minus(new Translation2d(0.0, GRADIENT_SAMPLE_METERS))))
            / (2.0 * GRADIENT_SAMPLE_METERS);
    return new double[] {dzdx, dzdy};
  }

  private double profileHeight(Translation2d point, RectRegion bounds) {
    if (!contains(bounds, point)) {
      return 0.0;
    }
    double progress = normalizedProgress(bounds.minX, bounds.maxX, point.getX());
    double rampFraction = Math.min(BUMP_RAMP_FRACTION, 0.5);
    if (progress <= rampFraction) {
      return BUMP_HEIGHT_METERS * (progress / rampFraction);
    }
    if (progress >= 1.0 - rampFraction) {
      return BUMP_HEIGHT_METERS * ((1.0 - progress) / rampFraction);
    }
    return BUMP_HEIGHT_METERS;
  }

  private double overheadClearanceMeters(TerrainFeature feature) {
    return switch (feature) {
      case BLUE_LEFT_TRENCH, BLUE_RIGHT_TRENCH, RED_LEFT_TRENCH, RED_RIGHT_TRENCH ->
          TRENCH_OPENING_HEIGHT_METERS;
      default -> Double.POSITIVE_INFINITY;
    };
  }

  private boolean traversableSurface(TerrainFeature feature) {
    return switch (feature) {
      case BLUE_HUB,
          RED_HUB,
          BLUE_TOWER,
          RED_TOWER,
          BLUE_LEFT_TRENCH_EDGE,
          BLUE_RIGHT_TRENCH_EDGE,
          RED_LEFT_TRENCH_EDGE,
          RED_RIGHT_TRENCH_EDGE -> false;
      default -> true;
    };
  }

  private static boolean contains(RectRegion region, Translation2d point) {
    return point.getX() >= region.minX
        && point.getX() <= region.maxX
        && point.getY() >= region.minY
        && point.getY() <= region.maxY;
  }

  private static double normalizedProgress(double min, double max, double value) {
    double span = Math.max(max - min, 1e-9);
    return Math.max(0.0, Math.min(1.0, (value - min) / span));
  }

  private static double hubCenterXBlue() {
    return HUB_CENTER_X_BLUE_METERS;
  }

  private static double hubCenterXRed() {
    return HUB_CENTER_X_RED_METERS;
  }

  private static boolean inBlueTower(Translation2d position) {
    return contains(blueTowerLeftWall(), position)
        || contains(blueTowerRightWall(), position)
        || contains(blueTowerBackWall(), position);
  }

  private static boolean inRedTower(Translation2d position) {
    return contains(redTowerLeftWall(), position)
        || contains(redTowerRightWall(), position)
        || contains(redTowerBackWall(), position);
  }

  private static RectRegion blueTowerLeftWall() {
    double towerCenterX = TOWER_FRONT_FACE_X_METERS - (TOWER_DEPTH_METERS * 0.5);
    double centerY =
        BLUE_TOWER_CENTER_Y_METERS
            + (TOWER_INNER_OPENING_WIDTH_METERS * 0.5)
            + (TOWER_SIDE_WIDTH_METERS * 0.5);
    return centeredRect(towerCenterX, centerY, TOWER_DEPTH_METERS, TOWER_SIDE_WIDTH_METERS);
  }

  private static RectRegion blueTowerRightWall() {
    double towerCenterX = TOWER_FRONT_FACE_X_METERS - (TOWER_DEPTH_METERS * 0.5);
    double centerY =
        BLUE_TOWER_CENTER_Y_METERS
            - (TOWER_INNER_OPENING_WIDTH_METERS * 0.5)
            - (TOWER_SIDE_WIDTH_METERS * 0.5);
    return centeredRect(towerCenterX, centerY, TOWER_DEPTH_METERS, TOWER_SIDE_WIDTH_METERS);
  }

  private static RectRegion blueTowerBackWall() {
    return centeredRect(
        TOWER_FRONT_FACE_X_METERS - TOWER_DEPTH_METERS,
        BLUE_TOWER_CENTER_Y_METERS,
        Units.inchesToMeters(2.0),
        TOWER_WIDTH_METERS);
  }

  private static RectRegion redTowerLeftWall() {
    double towerCenterX = RED_TOWER_FRONT_FACE_X_METERS + (TOWER_DEPTH_METERS * 0.5);
    double centerY =
        RED_TOWER_CENTER_Y_METERS
            + (TOWER_INNER_OPENING_WIDTH_METERS * 0.5)
            + (TOWER_SIDE_WIDTH_METERS * 0.5);
    return centeredRect(towerCenterX, centerY, TOWER_DEPTH_METERS, TOWER_SIDE_WIDTH_METERS);
  }

  private static RectRegion redTowerRightWall() {
    double towerCenterX = RED_TOWER_FRONT_FACE_X_METERS + (TOWER_DEPTH_METERS * 0.5);
    double centerY =
        RED_TOWER_CENTER_Y_METERS
            - (TOWER_INNER_OPENING_WIDTH_METERS * 0.5)
            - (TOWER_SIDE_WIDTH_METERS * 0.5);
    return centeredRect(towerCenterX, centerY, TOWER_DEPTH_METERS, TOWER_SIDE_WIDTH_METERS);
  }

  private static RectRegion redTowerBackWall() {
    return centeredRect(
        RED_TOWER_FRONT_FACE_X_METERS + TOWER_DEPTH_METERS,
        RED_TOWER_CENTER_Y_METERS,
        Units.inchesToMeters(2.0),
        TOWER_WIDTH_METERS);
  }

  private static RectRegion centeredRect(
      double centerX, double centerY, double widthMeters, double heightMeters) {
    return new RectRegion(
        centerX - (widthMeters * 0.5),
        centerX + (widthMeters * 0.5),
        centerY - (heightMeters * 0.5),
        centerY + (heightMeters * 0.5));
  }

  private static RectRegion trenchSupportBox(
      double trenchCenterX, double trenchCenterY, boolean blueSide) {
    double trenchMinX = trenchCenterX - (TRENCH_FOOTPRINT_DEPTH_METERS * 0.5);
    double trenchMaxX = trenchCenterX + (TRENCH_FOOTPRINT_DEPTH_METERS * 0.5);
    double supportCenterX =
        blueSide
            ? trenchMaxX - (TRENCH_SUPPORT_DEPTH_METERS * 0.5)
            : trenchMinX + (TRENCH_SUPPORT_DEPTH_METERS * 0.5);
    return centeredRect(
        supportCenterX, trenchCenterY, TRENCH_SUPPORT_DEPTH_METERS, TRENCH_FOOTPRINT_WIDTH_METERS);
  }

  private static Segment[] trenchWallSegments(
      double trenchCenterX, double trenchCenterY, boolean blueSide) {
    double trenchMinX = trenchCenterX - (TRENCH_FOOTPRINT_DEPTH_METERS * 0.5);
    double trenchMaxX = trenchCenterX + (TRENCH_FOOTPRINT_DEPTH_METERS * 0.5);
    double supportBoundaryX =
        blueSide ? trenchMaxX - TRENCH_SUPPORT_DEPTH_METERS : trenchMinX + TRENCH_SUPPORT_DEPTH_METERS;
    double openMinX = blueSide ? trenchMinX : supportBoundaryX;
    double openMaxX = blueSide ? supportBoundaryX : trenchMaxX;
    double topY = trenchCenterY + (TRENCH_FOOTPRINT_WIDTH_METERS * 0.5);
    double bottomY = trenchCenterY - (TRENCH_FOOTPRINT_WIDTH_METERS * 0.5);

    return new Segment[] {
      new Segment(new Translation2d(openMinX, topY), new Translation2d(openMaxX, topY)),
      new Segment(new Translation2d(openMinX, bottomY), new Translation2d(openMaxX, bottomY))
    };
  }

  public static double fieldLengthMeters() {
    return FIELD_LENGTH_METERS;
  }

  public static double fieldWidthMeters() {
    return FIELD_WIDTH_METERS;
  }

  public static double hubCenterXBlueMeters() {
    return hubCenterXBlue();
  }

  public static double hubCenterXRedMeters() {
    return hubCenterXRed();
  }

  public static double hubCenterYMeters() {
    return HUB_CENTER_Y_METERS;
  }

  public static double hubCollisionSizeMeters() {
    return (BLUE_HUB_BOUNDS.maxX - BLUE_HUB_BOUNDS.minX + BLUE_HUB_BOUNDS.maxY - BLUE_HUB_BOUNDS.minY)
        * 0.25;
  }

  public static double hubCollisionWidthMeters() {
    return HUB_COLLISION_WIDTH_METERS;
  }

  public static double hubCollisionHeightMeters() {
    return HUB_COLLISION_HEIGHT_METERS;
  }

  public static double blueTowerFrontFaceXMeters() {
    return TOWER_FRONT_FACE_X_METERS;
  }

  public static double redTowerFrontFaceXMeters() {
    return RED_TOWER_FRONT_FACE_X_METERS;
  }

  public static double towerWidthMeters() {
    return TOWER_WIDTH_METERS;
  }

  public static double towerDepthMeters() {
    return TOWER_DEPTH_METERS;
  }

  public static double blueTowerCenterYMeters() {
    return BLUE_TOWER_CENTER_Y_METERS;
  }

  public static double redTowerCenterYMeters() {
    return RED_TOWER_CENTER_Y_METERS;
  }

  public static double blueTrenchCenterXMeters() {
    return TRENCH_CENTER_X_BLUE_METERS;
  }

  public static double redTrenchCenterXMeters() {
    return TRENCH_CENTER_X_RED_METERS;
  }

  public static double trenchDepthMeters() {
    return TRENCH_FOOTPRINT_DEPTH_METERS;
  }

  public static double blueLeftTrenchBlockCenterYMeters() {
    return BLUE_LEFT_TRENCH_BLOCK_BOUNDS.centerY();
  }

  public static double blueRightTrenchBlockCenterYMeters() {
    return BLUE_RIGHT_TRENCH_BLOCK_BOUNDS.centerY();
  }

  public static double redLeftTrenchBlockCenterYMeters() {
    return RED_LEFT_TRENCH_BLOCK_BOUNDS.centerY();
  }

  public static double redRightTrenchBlockCenterYMeters() {
    return RED_RIGHT_TRENCH_BLOCK_BOUNDS.centerY();
  }

  public static double leftTrenchBlockWidthMeters() {
    return BLUE_LEFT_TRENCH_BLOCK_BOUNDS.maxY - BLUE_LEFT_TRENCH_BLOCK_BOUNDS.minY;
  }

  public static double rightTrenchBlockWidthMeters() {
    return BLUE_RIGHT_TRENCH_BLOCK_BOUNDS.maxY - BLUE_RIGHT_TRENCH_BLOCK_BOUNDS.minY;
  }

  public static double blueLeftTrenchCenterYMeters() {
    return TRENCH_UPPER_CENTER_Y_METERS;
  }

  public static double blueRightTrenchCenterYMeters() {
    return TRENCH_LOWER_CENTER_Y_METERS;
  }

  public static double redLeftTrenchCenterYMeters() {
    return TRENCH_UPPER_CENTER_Y_METERS;
  }

  public static double redRightTrenchCenterYMeters() {
    return TRENCH_LOWER_CENTER_Y_METERS;
  }

  public static RectRegion blueLeftTrenchSupportBox() {
    return BLUE_LEFT_TRENCH_BLOCK_BOUNDS;
  }

  public static RectRegion blueRightTrenchSupportBox() {
    return BLUE_RIGHT_TRENCH_BLOCK_BOUNDS;
  }

  public static RectRegion redLeftTrenchSupportBox() {
    return RED_LEFT_TRENCH_BLOCK_BOUNDS;
  }

  public static RectRegion redRightTrenchSupportBox() {
    return RED_RIGHT_TRENCH_BLOCK_BOUNDS;
  }

  public static Segment[] blueLeftTrenchWalls() {
    return trenchWallSegments(TRENCH_CENTER_X_BLUE_METERS, TRENCH_UPPER_CENTER_Y_METERS, true);
  }

  public static Segment[] blueRightTrenchWalls() {
    return trenchWallSegments(TRENCH_CENTER_X_BLUE_METERS, TRENCH_LOWER_CENTER_Y_METERS, true);
  }

  public static Segment[] redLeftTrenchWalls() {
    return trenchWallSegments(TRENCH_CENTER_X_RED_METERS, TRENCH_UPPER_CENTER_Y_METERS, false);
  }

  public static Segment[] redRightTrenchWalls() {
    return trenchWallSegments(TRENCH_CENTER_X_RED_METERS, TRENCH_LOWER_CENTER_Y_METERS, false);
  }

  private static void addHubMarkers(List<FieldMarkerSample> markers) {
    addMarker(markers, "blue-hub", BLUE_HUB_BOUNDS.center3d(BUMP_HEIGHT_METERS * 0.5));
    addMarker(markers, "red-hub", RED_HUB_BOUNDS.center3d(BUMP_HEIGHT_METERS * 0.5));
  }

  private static void addBumpMarkers(List<FieldMarkerSample> markers) {
    addMarker(markers, "blue-left-bump", BLUE_LEFT_BUMP_BOUNDS.center3d(BUMP_HEIGHT_METERS * 0.5));
    addMarker(
        markers, "blue-right-bump", BLUE_RIGHT_BUMP_BOUNDS.center3d(BUMP_HEIGHT_METERS * 0.5));
    addMarker(markers, "red-left-bump", RED_LEFT_BUMP_BOUNDS.center3d(BUMP_HEIGHT_METERS * 0.5));
    addMarker(markers, "red-right-bump", RED_RIGHT_BUMP_BOUNDS.center3d(BUMP_HEIGHT_METERS * 0.5));
  }

  private static void addTrenchMarkers(List<FieldMarkerSample> markers) {
    addMarker(
        markers,
        "blue-left-trench-open",
        BLUE_LEFT_TRENCH_OPEN_BOUNDS.center3d(TRENCH_OPENING_HEIGHT_METERS));
    addMarker(
        markers,
        "blue-right-trench-open",
        BLUE_RIGHT_TRENCH_OPEN_BOUNDS.center3d(TRENCH_OPENING_HEIGHT_METERS));
    addMarker(
        markers,
        "red-left-trench-open",
        RED_LEFT_TRENCH_OPEN_BOUNDS.center3d(TRENCH_OPENING_HEIGHT_METERS));
    addMarker(
        markers,
        "red-right-trench-open",
        RED_RIGHT_TRENCH_OPEN_BOUNDS.center3d(TRENCH_OPENING_HEIGHT_METERS));
  }

  private static void addTrenchEdgeMarkers(List<FieldMarkerSample> markers) {
    addMarker(
        markers,
        "blue-left-trench-edge",
        BLUE_LEFT_TRENCH_BLOCK_BOUNDS.center3d(TRENCH_OPENING_HEIGHT_METERS * 0.5));
    addMarker(
        markers,
        "blue-right-trench-edge",
        BLUE_RIGHT_TRENCH_BLOCK_BOUNDS.center3d(TRENCH_OPENING_HEIGHT_METERS * 0.5));
    addMarker(
        markers,
        "red-left-trench-edge",
        RED_LEFT_TRENCH_BLOCK_BOUNDS.center3d(TRENCH_OPENING_HEIGHT_METERS * 0.5));
    addMarker(
        markers,
        "red-right-trench-edge",
        RED_RIGHT_TRENCH_BLOCK_BOUNDS.center3d(TRENCH_OPENING_HEIGHT_METERS * 0.5));
  }

  private static void addTowerMarkers(List<FieldMarkerSample> markers) {
    double blueLeftUprightY = BLUE_TOWER_CENTER_Y_METERS + TOWER_INNER_OPENING_WIDTH_METERS * 0.5 + TOWER_UPRIGHT_OFFSET_METERS;
    double blueRightUprightY = BLUE_TOWER_CENTER_Y_METERS - TOWER_INNER_OPENING_WIDTH_METERS * 0.5 - TOWER_UPRIGHT_OFFSET_METERS;
    double redLeftUprightY = RED_TOWER_CENTER_Y_METERS + TOWER_INNER_OPENING_WIDTH_METERS * 0.5 + TOWER_UPRIGHT_OFFSET_METERS;
    double redRightUprightY = RED_TOWER_CENTER_Y_METERS - TOWER_INNER_OPENING_WIDTH_METERS * 0.5 - TOWER_UPRIGHT_OFFSET_METERS;

    addMarker(
        markers,
        "blue-tower-left-upright",
        new Translation3d(TOWER_FRONT_FACE_X_METERS, blueLeftUprightY, TOWER_UPRIGHT_HEIGHT_METERS * 0.5));
    addMarker(
        markers,
        "blue-tower-right-upright",
        new Translation3d(TOWER_FRONT_FACE_X_METERS, blueRightUprightY, TOWER_UPRIGHT_HEIGHT_METERS * 0.5));
    addMarker(
        markers,
        "red-tower-left-upright",
        new Translation3d(RED_TOWER_FRONT_FACE_X_METERS, redLeftUprightY, TOWER_UPRIGHT_HEIGHT_METERS * 0.5));
    addMarker(
        markers,
        "red-tower-right-upright",
        new Translation3d(RED_TOWER_FRONT_FACE_X_METERS, redRightUprightY, TOWER_UPRIGHT_HEIGHT_METERS * 0.5));
    addMarker(markers, "blue-tower-back-wall", blueTowerBackWall().center3d(TOWER_UPRIGHT_HEIGHT_METERS * 0.5));
    addMarker(markers, "red-tower-back-wall", redTowerBackWall().center3d(TOWER_UPRIGHT_HEIGHT_METERS * 0.5));
  }

  private static void addMarker(List<FieldMarkerSample> markers, String id, Translation3d translation3d) {
    markers.add(new FieldMarkerSample(id, new Pose3d(translation3d, new Rotation3d())));
  }

  private static RectRegion cadRect(
      double cadMinXMm, double cadMaxXMm, double cadMinYMm, double cadMaxYMm) {
    return new RectRegion(
        cadXToField(cadMinXMm),
        cadXToField(cadMaxXMm),
        cadYToField(cadMinYMm),
        cadYToField(cadMaxYMm));
  }

  private static double cadXToField(double cadXMillimeters) {
    return (cadXMillimeters / 1000.0) + CAD_FIELD_ORIGIN_X_METERS;
  }

  private static double cadYToField(double cadYMillimeters) {
    return (cadYMillimeters / 1000.0) + CAD_FIELD_ORIGIN_Y_METERS;
  }

  private static double cadXSpanToField(double cadSpanMillimeters) {
    return cadSpanMillimeters / 1000.0;
  }

  private static double cadYSpanToField(double cadSpanMillimeters) {
    return cadSpanMillimeters / 1000.0;
  }

  public record RectRegion(double minX, double maxX, double minY, double maxY) {
    Translation3d center3d(double z) {
      return new Translation3d((minX + maxX) * 0.5, (minY + maxY) * 0.5, z);
    }

    double centerX() {
      return (minX + maxX) * 0.5;
    }

    double centerY() {
      return (minY + maxY) * 0.5;
    }
  }

  public record Segment(Translation2d start, Translation2d end) {}
}
